/*
CODE de base pour la récupération des données de 3 Trill
Et la récupération des valeurs des 8 entrées analog (potars)

TRILL SQUARE 1 et 2:
Un array par sensor
gSquare1[] et gSquare2[];
0	:	Pression
1	:	X
2	:	Y

TRILL BAR
gNumActiveTouches	:	Nombre de doights
1 array par donnée (Les données d'un doigths sont séparés en 2 array)
gTouchLocation[]	:	Une valeur par doight. Position (1 à 0 = inversé).
gTouchSize[]		:	Une valeur par doight. Pression.

ANALOG DATA
Toutes les valeurs dans un array:
gPotar[]

NOTE:
penser à la fonction map(donnee, InMin, InMax, OutMin, OutMax)
*/

#include <Bela.h>
#include <algorithm>
#include <cmath>

#include <grain.h>

#define FAUSTFLOAT float

// --- TRILL DATA ------------------------------ //
#include <libraries/Trill/Trill.h>
#define NUM_TOUCH 5
std::vector<Trill*> gTouchSensors;
unsigned int gSampleCount = 0;
float gSendInterval = 0.1;
unsigned int gSendIntervalSamples;
// TRILL SQUARE (Les 2)
float gSquare1[3];
float gSquare2[3];
// TRILL BAR:
// Location of touches on Trill Bar
float gTouchLocation[NUM_TOUCH] = { 0.0, 0.0, 0.0, 0.0, 0.0};
// Size of touches on Trill bar
float gTouchSize[NUM_TOUCH] = { 0.0, 0.0, 0.0, 0.0, 0.0};
// Number of active touches
int gNumActiveTouches = 0;
// Aux Task lecture I2C pour TRILL:
void readLoop(void*)
{
	while(!Bela_stopRequested())
	{
		for(unsigned int n = 0; n < gTouchSensors.size(); ++n)
		{
			Trill* t = gTouchSensors[n];
			t->readI2C();
		}
		usleep(50000);
	}
}

// --- ANALOG DATA ----------------------------- //
int gAudioFramesPerAnalogFrame = 0;
// Set the analog channels to read from
float gPotar[8];

const int NBGRAINS = 70;

int tmpGCounter = 0;
int tmpGrainCounter = 0;
int samplePerBlocs = 3000;
grain tablograin[NBGRAINS];
int tabloSPAT[NBGRAINS];
float tmpaudio[8];// Samples des 8 sorties.

float GPopul=0.5; //Duree CLK général de declanchement des grains.
float GFreq = 220.;
float GRNDFreq = 220.;
float GAmp = 1.;
float GDur = 1.;
int GPos = 0;
float rndPos = 0;


// --------------------------------------------- //
// --- SETUP ----------------------------------- //
// --------------------------------------------- //
bool setup(BelaContext *context, void *userData)
{
// --- TRILL PROCESS --------------------------- //
	unsigned int i2cBus = 1;
	for(uint8_t addr = 0x20; addr <= 0x50; ++addr)
	{
		Trill::Device device = Trill::probe(i2cBus, addr);
		if(Trill::NONE != device && Trill::CRAFT != device)
		{
			gTouchSensors.push_back(new Trill(i2cBus, device, addr));
			gTouchSensors.back()->printDetails();
		}
		if(Trill::BAR == device)
		{
			rt_printf("un BAR\n");
		}
		if(Trill::SQUARE == device)
		{
			rt_printf("un SQUARE\n");
		}
	}
	Bela_runAuxiliaryTask(readLoop);

// --- ANALOG PROCESS -------------------------- //
	// Check if analog channels are enabled
	if(context->analogFrames == 0 || context->analogFrames > context->audioFrames) {
		rt_printf("Error: this example needs analog enabled, with 4 or 8 channels\n");
		return false;
	}
	// Useful calculations
	if(context->analogFrames)
		gAudioFramesPerAnalogFrame = context->audioFrames / context->analogFrames;
		
// --- AUTRES PROCESS -------------------------- //		
	gSendIntervalSamples = context->audioSampleRate * gSendInterval;
	samplePerBlocs = int (context->audioSampleRate / context->audioFrames);
// --- CLASS  PROCESS -------------------------- //		
	float tmptablo[11] = {0.6, 0., 0., 220., 0., 220., 0., 1., 1., 0.5, 0.};
	for (int i = 0; i<NBGRAINS;i++){
		tablograin[i].initGrain(context->audioSampleRate);
		tablograin[i].initParametres(tmptablo);
		tabloSPAT[i] = 0;
	}
	return true;
}

/*
		GAmp		fHslider0		, 0.5f, 0.0f, 1.0f, 0.00100000005f);
		NoizAmp		fHslider1		, 0.0f, -1.0f, 1.0f, 0.00100000005f);
		GRndA		fHslider2		, 0.0f, 0.0f, 0.5f, 0.00100000005f);
		GFreq		fHslider3		, 880.0f, 100.0f, 10000.0f, 0.00999999978f);
		NoizFreq	fHslider4		, 0.0f, -1.0f, 1.0f, 0.00100000005f);
		GRndF		fHslider5		, 880.0f, 100.0f, 10000.0f, 0.00999999978f);
		GFdistri	fHslider6		, 0.0f, 0.0f, 1.0f, 0.00100000005f);
		GPopul		fHslider7		, 9.99999975e-05f, 9.99999975e-05f, 1.0f, 9.99999975e-05f);
		GDuree		fHslider8		, 1.0f, 9.99999975e-05f, 1.0f, 9.99999975e-05f);
		GEnv		fHslider9		, 0.5f, 9.99999975e-05f, 0.999899983f, 9.99999975e-05f);
*/
// --------------------------------------------- //
// --- RENDER ---------------------------------- //
// --------------------------------------------- //
void render(BelaContext *context, void *userData)
{
//int tmpGCounter = 0;
//int tmpGrainCounter = 0;
	// COMPTEUR = déclanchement des grains: Se fait un fois par audioframe.
	// Pour l'instant, pas de random (= grains strictement séquencé) (gDistri...) A voir si pertinent, plus tard.

	int countGtime = int(float(samplePerBlocs) * GPopul / float(NBGRAINS));
	tmpGCounter ++;
	if (tmpGCounter > countGtime){
		tmpGCounter = 0;
		// RANDOMS
		float rndf = rand()/ (float)RAND_MAX;
		float rnda = rand()/ (float)RAND_MAX;
		
		// Recup valeurs des comandes (Potar et Trills)
		float env = map (gPotar[1], 0. , 1. , 0.001, 0.999);
		float fdistr = gPotar[0];
		if(gTouchSize[0]>0.6 && gNumActiveTouches == 1){
			float tmp = map ((1. -gTouchLocation[0]), 0. ,1. , 20., 100.);	//Freq
			GFreq = (440.0f * std::pow(2.0f, (0.0833333358f * (float(tmp) + -69.0f))));
			GRNDFreq = GFreq;
			GAmp = map (gTouchSize[0], 0.6 ,1.5 , 0., 1.);				//Vol
		}
		//float fSlow0 = (440.0f * std::pow(2.0f, (0.0833333358f * (float(fHslider0) + -69.0f))));
		if(gTouchSize[0]>0.6 && gNumActiveTouches == 2){
			if (gTouchLocation[0] > gTouchLocation[1]){
				float tmp = map ((1. -gTouchLocation[0]), 0. ,1. , 20., 100.);	//Freq
				GFreq = (440.0f * std::pow(2.0f, (0.0833333358f * (float(tmp) + -69.0f))));
				GAmp = map (gTouchSize[0], 0.6 ,1.5 , 0., 1.);				//Vol
				tmp = map ((1. -gTouchLocation[1]), 0. ,1. , 20., 100.);	//Freq
				GRNDFreq = (440.0f * std::pow(2.0f, (0.0833333358f * (float(tmp) + -69.0f))));
			} else {
				float tmp = map ((1. -gTouchLocation[1]), 0. ,1. , 20., 100.);	//Freq
				GFreq = (440.0f * std::pow(2.0f, (0.0833333358f * (float(tmp) + -69.0f))));
				GAmp = map (gTouchSize[1], 0.6 ,1.5 , 0., 1.);				//Vol
				tmp = map ((1. -gTouchLocation[0]), 0. ,1. , 20., 100.);	//Freq
				GRNDFreq = (440.0f * std::pow(2.0f, (0.0833333358f * (float(tmp) + -69.0f))));
			}
		}
		if (gNumActiveTouches == 0){
			GAmp = 0.;
		}
		float RNDampl = (gPotar[2] * GAmp)-GAmp;
		if (gSquare1[0] > 0.5){
			GPopul = map (gSquare1[2], 0. ,1. , 0.01, 2.);		//GPopul
			GDur = gSquare1[1];	//GDur
		}
		
		// INIT des parametres du grain:
		float tmptablo[11] = {GAmp, rnda, RNDampl, GFreq, rndf, GRNDFreq, fdistr, GPopul, GDur, env, 1.};
		tablograin[tmpGrainCounter].initParametres(tmptablo);
		
		// A Part: SPAT
		if (gSquare2[0] > 0.5){
			GPos = int(gSquare2[2]*8);			//Rotat
			rndPos = gSquare2[1];			//Decal
		}
		int rndspat = (int ((rand()/ (float)RAND_MAX)*8*rndPos) + GPos)%8;
		tabloSPAT[tmpGrainCounter] = int(rndspat);

		tmpGrainCounter++;
		if (tmpGrainCounter >= NBGRAINS){
			tmpGrainCounter = 0;
		}

	}
	// FIN COMPTEUR
	
	for(unsigned int n = 0; n < context->audioFrames; ++n)
	{
// --- TRILL PROCESS --------------------------- //
		gSampleCount++;
		if(gSampleCount == gSendIntervalSamples)
		{
			gSampleCount = 0;
			// Les 2 TRILL SQUARE
			// Le 1er
			gSquare1[0] = gTouchSensors[1]->compoundTouchSize();
			gSquare1[1] = gTouchSensors[1]->compoundTouchLocation();
			gSquare1[2] = gTouchSensors[1]->compoundTouchHorizontalLocation();
			// Le 2e
			gSquare2[0] = gTouchSensors[2]->compoundTouchSize();
			gSquare2[1] = gTouchSensors[2]->compoundTouchLocation();
			gSquare2[2] = gTouchSensors[2]->compoundTouchHorizontalLocation();
			//rt_printf("[%d] %2.3f %.3f %.3f  ", 1, gSquare1[0], gSquare1[1], gSquare1[2]);
			//rt_printf("[%d] %2.3f %.3f %.3f  ", 2, gSquare2[0], gSquare2[1], gSquare2[2]);
			// Le TRILL BAR
			gNumActiveTouches = gTouchSensors[0]->getNumTouches();
			for(unsigned int i = 0; i < gNumActiveTouches; i++) {
				gTouchLocation[i] = gTouchSensors[0]->touchLocation(i);
				gTouchSize[i] = gTouchSensors[0]->touchSize(i);
				//rt_printf("[ 0 %d] %.3f %.3f ", i, gTouchSize[i], gTouchLocation[i]);
			}
			
			//rt_printf("\n");
		}
		
// --- ANALOG PROCESS -------------------------- //
		if(gAudioFramesPerAnalogFrame && !(n % gAudioFramesPerAnalogFrame)) {
			for (unsigned int i=0; i <8; i++){
				gPotar[i] = analogRead(context, n/gAudioFramesPerAnalogFrame, i);
			}
		}
// --- AUTRES PROCESS -------------------------- //
		for (int i = 0; i<8;i++){
			tmpaudio[i] = 0.;
		}
		for (int i = 0; i<NBGRAINS;i++){
			int possig = tabloSPAT[i];
			tmpaudio[possig] = tmpaudio[possig] + tablograin[i].processGrain();
		}
		//for(unsigned int ch = 0; ch < 8; ch++){
		for(unsigned int channel = 0; channel < 8; channel++) {
			audioWrite(context, n, channel, tmpaudio[channel]);
		}
	}
}

// --------------------------------------------- //
// --- CLEANUP --------------------------------- //
// --------------------------------------------- //
void cleanup(BelaContext *context, void *userData)
{
	for(auto t : gTouchSensors)
		delete t;
}
