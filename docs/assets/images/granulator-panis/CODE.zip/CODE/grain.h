/***** grain.h *****/
/*
*	Chaque grain est créé au début dans le setup. un nombre fixe.
*	(Non: on ne créer pas un grain à chaque fois qu'on en a besoin d'un, et qui se détruit quand il est revenu à un volume de 0).
*	Quand on a besoin de réactiver le grain (le faire jouer, le "créer"), on réinit ses paramètres: initParametres();
*	Tous les grains, meêm quand ils sont silencieux, sont processés dan sle render, par la méthode processGrain();
*
*	Tous le fSlider sont supprimés: Ils sont utiles que dans le initParametres, et les valeurs correspondantes sont regroupés dans le tableau allParam.

		GAmp		fHslider0		, 0.5f, 0.0f, 1.0f, 0.00100000005f);
		NoizAmp		fHslider1		, 0.0f, -1.0f, 1.0f, 0.00100000005f);
		GRndA		fHslider2		, 0.0f, 0.0f, 0.5f, 0.00100000005f);
		GFreq		fHslider3		, 880.0f, 100.0f, 10000.0f, 0.00999999978f);
		NoizFreq	fHslider4		, 0.0f, -1.0f, 1.0f, 0.00100000005f);
		GRndF		fHslider5		, 880.0f, 100.0f, 10000.0f, 0.00999999978f);
		GFdistri	fHslider6		, 0.0f, 0.0f, 1.0f, 0.00100000005f);
		GPopul		fHslider7		, 9.99999975e-05f, 9.99999975e-05f, 1.0f, 9.99999975e-05f);
		GDuree		fHslider8		, 1.0f, 9.99999975e-05f, 1.0f, 9.99999975e-05f);
		GEnv		fHslider9		, 0.5f, 9.99999975e-05f, 0.999899983f, 9.99999975e-05f);
		ExtTrig		fHslider10		<-- Pas dans tableau: si on init un grain, c'est qu'on le déclanche: on met à 1. Puis dans le process, tout à la fin, on le met à 0.
*
*
*/

#include <Bela.h>
#include <cmath>
#include <stdlib.h>
#include <time.h>
#ifndef GRAIN_H
#define GRAIN_H

class grain {
public:
	grain();
	// initialisation du grain. Necessite context->audioSampleRate
	void initGrain(long samprate);
	// modification des parametres, recalcule des coefs du grain = pour chaque "creation" du grain.
	void initParametres(float allParam[]);
	// calcule du grain (à utiliser dans le render)
	float processGrain();
	
	
private:
	int fSampleRate;
	float fConst0;
	float fConst1;
	int iVec0[2];
	float fRec0[2];
	float fRec1[2];
	float fConst2;
	float fVec1[2];
	int iRec2[2];
	
	float fSlow0;
	float fSlow1;
	float fSlow2;
	float fSlow3;
	float fSlow4;
	float fSlow5;
	float fSlow6;
	float fSlow7;
	float fSlow8;
	float fSlow9;
	float fSlow10;
	float fSlow11;
	float fSlow12;
	float fSlow13;
};
#endif