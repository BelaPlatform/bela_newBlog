/***** grain.cpp *****/

#include "grain.h"
#include <stdlib.h>

// Constructeur:
grain::grain() {
		for (int l0 = 0; (l0 < 2); l0 = (l0 + 1)) {
			iVec0[l0] = 0;
		}
		for (int l1 = 0; (l1 < 2); l1 = (l1 + 1)) {
			fRec0[l1] = 0.0f;
		}
		for (int l2 = 0; (l2 < 2); l2 = (l2 + 1)) {
			fRec1[l2] = 0.0f;
		}
		for (int l3 = 0; (l3 < 2); l3 = (l3 + 1)) {
			fVec1[l3] = 0.0f;
		}
		for (int l4 = 0; (l4 < 2); l4 = (l4 + 1)) {
			iRec2[l4] = 0;
		}
		fSlow0 = 0;
		fSlow1 = 440.;
		fSlow2 = 0;
		fSlow3 = 0;
		fSlow4 = 0;
		fSlow5 = 0;
		fSlow6 = 0;
		fSlow7 = 0;
		fSlow8 = 0;
		fSlow9 = 0;
		fSlow10 = 0;
		fSlow11 = 0;
		fSlow12 = 0;
		fSlow13 = 0;
		
}

// initialisation du grain. Necessite context->audioSampleRate
void grain::initGrain(long samprate){
		fSampleRate = samprate;
		fConst0 = min(192000.0f, max(1.0f, float(fSampleRate)));
		fConst1 = (6.28318548f / fConst0);
		fConst2 = (0.5f * fConst0);
}

// modification des parametres, recalcule des coefs du grain = pour chaque "creation" du grain.
void grain::initParametres(float allParam[]){
	fSlow0 = 0.2 * (allParam[0]- (allParam[1] * allParam[2]));	// Gestion volume
	// PARAMS EN RAPPORT AVEC FREQUENCE
	fSlow1 = allParam[3];//GFreq	
	fSlow2 = allParam[4];//NoizFreq
	fSlow3 = allParam[5];//GRndF
	fSlow4 = allParam[6];//GFdistri
	// CALCULE DE LA FREQUENCE
	fSlow5 = (fConst1 * (((fSlow1 + (fSlow2 * (fSlow3 - fSlow1))) * (1.0f - fSlow4)) + ((fSlow1 * fSlow4) * float((int((fSlow2 * float((int((fSlow3 / fSlow1)) + -1)))) + 1)))));
	fSlow6 = std::sin(fSlow5);
	fSlow7 = std::cos(fSlow5);
	//
	fSlow8 = (allParam[7] * allParam[8]);
	fSlow9 = allParam[9];
	fSlow10 = max(1.0f, (fConst2 * (fSlow8 * fSlow9)));
	fSlow11 = (1.0f / fSlow10);
	fSlow12 = allParam[10];
	fSlow13 = (1.0f / max(1.0f, (fConst2 * (fSlow8 * (1.0f - fSlow9)))));
}

// calcule du grain (à utiliser dans le render)
float grain::processGrain(){

		iVec0[0] = 1;
		// SINUS
		fRec0[0] = ((fSlow6 * fRec1[1]) + (fSlow7 * fRec0[1]));
		fRec1[0] = ((float((1 - iVec0[1])) + (fSlow7 * fRec1[1])) - (fSlow6 * fRec0[1]));
		// FIn SINUS
		fVec1[0] = fSlow12;//Trig
		iRec2[0] = (((iRec2[1] + (iRec2[1] > 0)) * (fSlow12 <= fVec1[1])) + (fSlow12 > fVec1[1]));
		float fTemp0 = float(iRec2[0]);
		
		float out = float((fSlow0 * (fRec0[0] * max(0.0f, min((fSlow11 * fTemp0), ((fSlow13 * (fSlow10 - fTemp0)) + 1.0f))))));
		
		iVec0[1] = iVec0[0];
		fRec0[1] = fRec0[0];
		fRec1[1] = fRec1[0];
		fVec1[1] = fVec1[0];
		iRec2[1] = iRec2[0];
		fSlow12 = 0.;// Ajout au process: le trig est remis à 0... NOTE: devrait simplifier le code, + tard
	
		return out;
}
//------------------------------------------ Controles -------------------------------------------//